import React, {useState} from 'react';
import {View, StyleSheet, Text, TouchableOpacity, Image} from 'react-native';
import {DrawerContentScrollView} from '@react-navigation/drawer';
import {colors, images, strings} from '../../themes';
import {moderateScale} from '../../themes/styleConfig';
import LinearGradient from 'react-native-linear-gradient';

const SideMenu = props => {
  const [menu] = useState([
    {index: 0, name: strings.home, icon: images.home, isSelect: true},
    {index: 1, name: strings.joinBJP, icon: images.join, isSelect: false},
    {index: 2, name: strings.login, icon: images.login, isSelect: false},
  ]);

  return (
    <View style={styles.safeAreaContainer}>
      <DrawerContentScrollView
        {...props}
        contentContainerStyle={{
          flex: moderateScale(1),
        }}>
        <LinearGradient
          colors={['#7cba2a', '#80bf2d', '#5c891c']}
          angle={90}
          style={styles.drawerHeaderStyle}>
          <Image source={images.logo} style={styles.logoStyle} />
        </LinearGradient>
        <View style={styles.drawerContainer}>
          {menu.map((item, index) => {
            return (
              <View
                key={index}
                style={
                  item.isSelect
                    ? styles.drawerItemViewSelectedStyle
                    : styles.drawerItemViewUnSelectedStyle
                }>
                <Image
                  source={item.icon}
                  style={
                    item.isSelect
                      ? styles.drawerIconSelectedStyle
                      : styles.drawerIconUnSelectedStyle
                  }
                />
                <TouchableOpacity
                  activeOpacity={1}
                  style={styles.drawerItemStyle}
                  onPress={() => {
                    menu.filter(x =>
                      x.index === index
                        ? (x.isSelect = true)
                        : (x.isSelect = false),
                    );
                    props.navigation.navigate(item.name, {
                      screename: item.name,
                    });
                  }}>
                  <Text
                    style={
                      item.isSelect
                        ? styles.drawerLabelSelectedStyle
                        : styles.drawerLabelUnSelectedStyle
                    }>
                    {item.name}
                  </Text>
                </TouchableOpacity>
              </View>
            );
          })}
        </View>
      </DrawerContentScrollView>
    </View>
  );
};
const styles = StyleSheet.create({
  safeAreaContainer: {
    height: '100%',
    width: '100%',
    backgroundColor: '#8bd119',
  },
  drawerContainer: {
    height: '100%',
    width: '100%',
    backgroundColor: colors.white,
    paddingTop: moderateScale(10),
  },
  drawerHeaderStyle: {
    width: '100%',
    height: moderateScale(175),
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoStyle: {
    height: moderateScale(75),
    width: moderateScale(75),
    marginLeft: moderateScale(32),
    position: 'absolute',
    bottom: moderateScale(16),
    alignSelf: 'flex-start',
  },
  drawerItemViewUnSelectedStyle: {
    width: '100%',
    height: moderateScale(55),
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'center',
    paddingHorizontal: moderateScale(22),
  },
  drawerItemViewSelectedStyle: {
    width: '100%',
    height: moderateScale(55),
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'center',
    paddingHorizontal: moderateScale(22),
    backgroundColor: colors.gray,
  },
  drawerIconUnSelectedStyle: {
    height: moderateScale(25),
    width: moderateScale(25),
    resizeMode: 'contain',
    tintColor: colors.darkGray,
  },
  drawerIconSelectedStyle: {
    height: moderateScale(25),
    width: moderateScale(25),
    resizeMode: 'contain',
    tintColor: colors.orange,
  },
  drawerItemStyle: {
    width: '80%',
    height: '100%',
    paddingLeft: moderateScale(16),
    textAlign: 'center',
    justifyContent: 'center',
  },
  drawerLabelUnSelectedStyle: {
    color: colors.black,
    fontSize: moderateScale(16),
    paddingHorizontal: moderateScale(20),
    fontWeight: '600',
  },
  drawerLabelSelectedStyle: {
    color: colors.orange,
    fontSize: moderateScale(16),
    paddingHorizontal: moderateScale(20),
    fontWeight: '600',
  },
});
export default SideMenu;
