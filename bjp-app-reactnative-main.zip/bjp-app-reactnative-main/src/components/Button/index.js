import React from 'react';
import {StyleSheet, Text, TouchableOpacity} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import {colors} from '../../themes';
import {moderateScale} from '../../themes/styleConfig';

const Button = ({buttonTitle, onPress, style}) => {
  return (
    <LinearGradient
      colors={['#7cba2a', '#80bf2d', '#5c891c']}
      style={styles.buttonStyle}>
      <TouchableOpacity activeOpacity={1} onPress={onPress}>
        <Text style={styles.buttonTextStyle}>{buttonTitle}</Text>
      </TouchableOpacity>
    </LinearGradient>
  );
};
const styles = StyleSheet.create({
  buttonStyle: {
    width: '100%',
    height: moderateScale(50),
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: moderateScale(8),
  },
  buttonTextStyle: {
    color: colors.white,
    textAlign: 'center',
    fontSize: moderateScale(22),
    fontWeight: '600',
  },
});
export default Button;
