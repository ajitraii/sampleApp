import React from 'react';
import {
  StatusBar,
  SafeAreaView,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
} from 'react-native';
import {colors, images} from '../../themes';
import {moderateScale} from '../../themes/styleConfig';
import LinearGradient from 'react-native-linear-gradient';

const Header = ({title, isBack, isDrawer, onPressBack, onPressDrawer}) => {
  return (
    <SafeAreaView style={{backgroundColor: colors.green}}>
      <StatusBar backgroundColor={colors.green} barStyle={'light-content'} />
      <SafeAreaView style={{opacity: moderateScale(0)}} />
      <LinearGradient
        colors={['#C15B05', '#fa8408', '#F69732']}
        angle={90}
        style={styles.headerContainer}>
        <TouchableOpacity
          style={styles.iconButtonView}
          onPress={isBack ? onPressBack : onPressDrawer}>
          <Image
            source={isBack ? images.back : images.hamburger}
            style={styles.iconStyle}
          />
        </TouchableOpacity>
        <Text style={styles.headerText}>{title}</Text>
      </LinearGradient>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  headerContainer: {
    width: '100%',
    height: moderateScale(60),
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  headerText: {
    textAlign: 'center',
    alignSelf: 'center',
    fontSize: moderateScale(22),
    fontWeight: '500',
    color: colors.white,
  },
  iconButtonView: {
    flexDirection: 'row',
    alignItems: 'center',
    position: 'absolute',
    left: moderateScale(21),
  },
  iconStyle: {
    height: moderateScale(21),
    width: moderateScale(31),
    resizeMode: 'contain',
  },
});
export default Header;
