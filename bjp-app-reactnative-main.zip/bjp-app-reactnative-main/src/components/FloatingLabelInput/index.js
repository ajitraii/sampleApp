import React, {Component} from 'react';
import {View, Animated, TextInput} from 'react-native';
import {colors} from '../../themes';
import {moderateScale} from '../../themes/styleConfig';

export default class FloatingLabelInput extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isFocused: false,
    };
  }

  componentWillMount() {
    this._animatedIsFocused = new Animated.Value(0);
  }

  componentDidUpdate() {
    Animated.timing(this._animatedIsFocused, {
      toValue: this.state.isFocused || this.props.value !== '' ? 1 : 0,
      duration: 200,
    }).start();
  }

  handleFocus = () => this.setState({isFocused: true});
  handleBlur = () => this.setState({isFocused: false});

  render() {
    const {
      label,
      inputRef,
      selectedColor,
      unSelectedColor,
      paddingVertical,
      ...props
    } = this.props;
    const {isFocused} = this.state;
    const labelStyle = {
      position: 'absolute',
      left: 0,
      top: this._animatedIsFocused.interpolate({
        inputRange: [0, 1],
        outputRange: [18, 0],
      }),
      fontSize: this._animatedIsFocused.interpolate({
        inputRange: [0, 1],
        outputRange: [20, 14],
      }),
      color: this._animatedIsFocused.interpolate({
        inputRange: [0, 1],
        outputRange: [unSelectedColor, selectedColor],
      }),
    };
    return (
      <View style={{paddingVertical: paddingVertical}}>
        <Animated.Text style={labelStyle}>{label}</Animated.Text>
        <TextInput
          ref={inputRef}
          {...props}
          style={{
            height: moderateScale(30),
            fontSize: moderateScale(20),
            color: colors.black,
            borderBottomWidth: 1,
            borderBottomColor: isFocused ? selectedColor : unSelectedColor,
          }}
          underlineColorAndroid={colors.transparent}
          selectionColor={isFocused ? selectedColor : unSelectedColor}
          onFocus={this.handleFocus}
          onBlur={this.handleBlur}
        />
      </View>
    );
  }
}
