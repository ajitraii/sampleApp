import React from 'react';
import {View} from 'react-native';
const MemberRegistration = () => {
  return <View style={{flex: 1,backgroundColor:'yellow'}} />;
};

export default MemberRegistration;
