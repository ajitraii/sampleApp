import React from 'react';
import {View, ImageBackground} from 'react-native';
import {Button, Header} from '../../components';
import {images, strings} from '../../themes';
import styles from './styles';

const Home = ({navigation}) => {
  return (
    <View style={styles.headerContainer}>
      <Header
        title={strings.welcomeToAPBJP}
        isDrawer={true}
        onPressDrawer={() => navigation.openDrawer()}
      />
      <View style={styles.container}>
        <ImageBackground
          source={images.background}
          resizeMode={'cover'}
          style={styles.background}
        />
        <View style={styles.middleContainer}>
          <Button buttonTitle={strings.joinBJP} />
          <Button
            buttonTitle={strings.memberLogin}
            onPress={() => navigation.navigate(strings.login)}
          />
        </View>
      </View>
    </View>
  );
};

export default Home;
