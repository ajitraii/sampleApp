import {StyleSheet} from 'react-native';
import {moderateScale} from '../../themes/styleConfig';

export default StyleSheet.create({
  headerContainer: {
    flex: moderateScale(1),
    backgroundColor: 'white',
  },
  background: {
    position: 'absolute',
    height: '100%',
    width: '100%',
  },
  container: {
    flex: moderateScale(1),
    alignItems: 'center',
  },
  middleContainer: {
    width: '100%',
    marginTop: 200,
    padding: moderateScale(16),
  },
});
