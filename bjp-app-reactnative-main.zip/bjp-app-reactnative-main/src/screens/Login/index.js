import React, {useEffect, useState, useRef} from 'react';
import {
  SafeAreaView,
  StatusBar,
  Keyboard,
  KeyboardAvoidingView,
  View,
  ImageBackground,
  Image,
  TouchableOpacity,
  Text,
  Platform,
} from 'react-native';
import {FloatingLabelInput} from '../../components';
import {images, colors, strings} from '../../themes';
import styles from './styles';
import LinearGradient from 'react-native-linear-gradient';

const Login = ({navigation}) => {
  const usernameRef = useRef(null);
  const passwordRef = useRef(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  return (
    <ImageBackground
      source={images.background}
      resizeMode={'cover'}
      style={styles.background}>
      <SafeAreaView style={styles.headerContainer}>
        <StatusBar backgroundColor={colors.green} barStyle={'light-content'} />
        <KeyboardAvoidingView
          style={{flex: 1}}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
          <View style={styles.headerContainer}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => navigation.goBack()}>
              <Image style={styles.backIcon} source={images.back} />
            </TouchableOpacity>
            <Image style={styles.logoStyle} source={images.logo} />
            <View style={{marginTop: 20}}>
              <FloatingLabelInput
                inputRef={usernameRef}
                label={strings.username}
                selectedColor={colors.white}
                unSelectedColor={colors.black}
                paddingVertical={22}
                value={username}
                maxLength={10}
                returnKeyType={Platform.OS === 'ios' ? 'done' : 'next'}
                keyboardType={'phone-pad'}
                onChangeText={value => setUsername(value)}
                onSubmitEditing={() => {
                  passwordRef.current.focus();
                }}
              />
              <FloatingLabelInput
                inputRef={passwordRef}
                label={strings.password}
                selectedColor={colors.white}
                unSelectedColor={colors.black}
                paddingVertical={22}
                value={password}
                secureTextEntry={true}
                returnKeyType={'done'}
                onChangeText={value => setPassword(value)}
                onSubmitEditing={() => Keyboard.dismiss()}
              />
            </View>
            <TouchableOpacity style={styles.loginButton}>
              <Text style={styles.loginButtonText}>{strings.login}</Text>
            </TouchableOpacity>
            <View style={styles.forgotPasswordView}>
              <Text style={styles.forgotPasswordText}>{strings.joinBJP}</Text>
              <Text style={styles.forgotPasswordText}>
                {strings.forgotPassword}
              </Text>
            </View>
          </View>
          <LinearGradient
            colors={['#C15B05', '#fa8408', '#F69732']}
            angle={90}
            style={styles.bottomView}>
            <Text style={styles.forgotPasswordText}>{strings.poweredBy}</Text>
            <Image source={images.dipl} />
          </LinearGradient>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </ImageBackground>
  );
};

export default Login;
