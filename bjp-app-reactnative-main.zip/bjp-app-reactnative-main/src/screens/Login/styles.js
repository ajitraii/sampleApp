import {StyleSheet} from 'react-native';
import { colors } from '../../themes';
import {moderateScale, scale} from '../../themes/styleConfig';

export default StyleSheet.create({
  safeAreaViewContainer: {
    flex: moderateScale(1),
  },
  headerContainer: {
    flex: moderateScale(1),
    padding: moderateScale(16),
  },
  background: {
    position: 'absolute',
    height: '100%',
    width: '100%',
  },
  backButton: {
    height: moderateScale(30),
    width: moderateScale(30),
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    height: moderateScale(25),
    width: moderateScale(25),
    resizeMode: 'contain',
  },
  logoStyle: {
    height: moderateScale(175),
    width: moderateScale(175),
    alignSelf: 'center',
    resizeMode: 'contain',
  },
  loginButton: {
    width: '100%',
    height: scale(55),
    marginVertical: scale(20),
    backgroundColor: colors.white,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loginButtonText: {
    fontSize: scale(18),
    color: colors.black,
    fontWeight: '500',
  },
  forgotPasswordView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: moderateScale(10),
  },
  forgotPasswordText: {
    fontSize: scale(18),
    color: colors.white,
    fontWeight: '500',
  },
  bottomView: {
    width: '100%',
    height: moderateScale(60),
    position: 'absolute',
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
});
