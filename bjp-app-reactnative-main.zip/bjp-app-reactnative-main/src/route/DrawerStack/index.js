import * as React from 'react';
import {createDrawerNavigator} from '@react-navigation/drawer';
import {strings} from '../../themes';
import {SideMenu} from '../../components';
import {Home, MemberRegistration, Login} from '../../screens';

const Drawer = createDrawerNavigator();

const DrawerStack = () => {
  return (
    <Drawer.Navigator
      drawerContent={props => <SideMenu {...props} />}
      screenOptions={{
        headerShown: false,
        drawerType: 'front',
        gestureEnabled: false,
        drawerStyle: {
          width: '75%',
        },
      }}>
      <Drawer.Screen name={strings.home} component={Home} />
      <Drawer.Screen name={strings.joinBJP} component={MemberRegistration} />
      <Drawer.Screen name={strings.login} component={Login} />
    </Drawer.Navigator>
  );
};
export default DrawerStack;
