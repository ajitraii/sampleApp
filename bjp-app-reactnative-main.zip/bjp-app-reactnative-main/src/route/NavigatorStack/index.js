import {NavigationContainer} from '@react-navigation/native';
import React from 'react';
import DrawerStack from '../DrawerStack';

export default function NavigatorStack({}) {
  return (
    <NavigationContainer>
      <DrawerStack />
    </NavigationContainer>
  );
}
