import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {Login} from '../../screens';
import {strings} from '../../themes';

const Stack = createStackNavigator();

const AuthStack = () => {
  return (
    <Stack.Navigator
      screenOptions={{headerShown: false, gestureEnabled: false}}
      initialRouteName={strings.login}>
      <Stack.Screen name={strings.login} component={Login} />
    </Stack.Navigator>
  );
};
export default AuthStack;
