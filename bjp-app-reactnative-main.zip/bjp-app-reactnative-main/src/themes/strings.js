export default strings = {
  INTERNET_CONNECTION: 'Please Check Your Internet Connection.',
  appName: 'AP BJP',

  //Sidemenu
  home: 'Home',
  joinBJP: 'Join BJP',
  login: 'Login',

  //Home
  memberLogin: 'Member Login',
  welcomeToAPBJP: 'Welcome to AP BJP',

  //Login
  username: 'Username',
  password: 'Password',
  forgotPassword: 'Forgot Password',
  poweredBy: 'Powered By',
};
