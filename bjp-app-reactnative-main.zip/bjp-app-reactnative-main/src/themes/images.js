export default images = {
  background: require('../assets/images/background/bg.png'),
  logo: require('../assets/images/logo/logo.png'),
  dipl: require('../assets/images/dipl/dipl.png'),

  home: require('../assets/images/sidemenu/home.png'),
  join: require('../assets/images/sidemenu/join.png'),
  login: require('../assets/images/sidemenu/login.png'),

  hamburger: require('../assets/images/hamburger/hamburger.png'),
  back: require('../assets/images/back/back.png'),
};
