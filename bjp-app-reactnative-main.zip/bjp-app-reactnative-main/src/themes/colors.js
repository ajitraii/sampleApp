export default colors = {
  white: '#FFFFFF',
  black: '#000000',
  transparent: 'transparent',
  darkGray: '#706b6b',
  orange: '#f77d08',
  green: '#6fa521',
  gray: '#d5d7db',
};
