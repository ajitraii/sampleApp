import colors from './colors';
import strings from './strings';
import images from './images';

export {colors, strings, images};
