import React from 'react';
import NavigatorStack from './src/route/NavigatorStack';
const App = () => {
  return <NavigatorStack />;
};

export default App;
